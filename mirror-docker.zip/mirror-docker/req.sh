rin() {
pip install --upgrade pip
pip install --no-cache-dir anytree
pip install --no-cache-dir appdirs
pip install --no-cache-dir aria2p
pip install --no-cache-dir attrdict
pip install --no-cache-dir beautifulsoup4
pip install --no-cache-dir bencoding
pip install --no-cache-dir cfscrape
pip install --no-cache-dir feedparser
pip install --no-cache-dir flask
pip install --no-cache-dir google-api-python-client
pip install --no-cache-dir google-auth-httplib2
pip install --no-cache-dir google-auth-oauthlib
pip install --no-cache-dir gunicorn
pip install --no-cache-dir lk21
pip install --no-cache-dir lxml
pip install --no-cache-dir pillow
pip install --no-cache-dir psutil
pip install --no-cache-dir psycopg2-binary
pip install --no-cache-dir pybase64
pip install --no-cache-dir python-dotenv
pip install --no-cache-dir python-magic
pip install --no-cache-dir python-telegram-bot
pip install --no-cache-dir qbittorrent-api
pip install --no-cache-dir requests
pip install --no-cache-dir speedtest-cli
pip install --no-cache-dir six
pip install --no-cache-dir telegraph
pip install --no-cache-dir tenacity
pip install --no-cache-dir tgCrypto
pip install --no-cache-dir urllib3
pip install --no-cache-dir yt-dlp
pip install --no-cache-dir google-api-python-client
pip install --no-cache-dir progress
pip install --no-cache-dir progressbar2
pip install --no-cache-dir httplib2shim
pip install --no-cache-dir google_auth_oauthlib
pip install --no-cache-dir pyrogram
pip install --no-cache-dir megasdkrestclient
}
dl() {
apt update -y
apt upgrade -y
apt install sudo
apt install aria2 -y || sudo apt install aria2 -y
apt install wget -y || sudo apt install wget -y
apt install apt-utils -y || sudo apt install apt-utils -y
rin
}
dl
